# Pure Data Tutorial 
KHM Köln SoSe 2018

www.puredata.info
[Download Pure Data 0.48-1 here](http://puredata.info/downloads/pure-data)

PD Patches zu Plugsin
[Camomile](https://github.com/pierreguillot/Camomile)

Pd VJ tool
[Arrast VJ Tool](http://www.arrastvj.org/)

Pd External Ofelia (Visual/Video, Standalone Applications)
[Ofelia External](https://github.com/cuinjune/ofxOfelia)

