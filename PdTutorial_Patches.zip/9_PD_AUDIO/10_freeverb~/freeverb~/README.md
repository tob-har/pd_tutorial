freeverb~ - Freeverb is an implementation by Olaf Mattes, based on the 
Freeverb code put nicely in the public domain by "Jezar".

This git-fork of the Pure-data library freeverb~ is cloned from 
https://git.puredata.info/cgit/svn2git/libraries/freeverb~.git, which is 
the svn-to-git from 
https://sourceforge.net/p/pure-data/svn/HEAD/tree/trunk/externals/freeverb~/.

This repository replaces the Library Template Makefile by the pd-lib-builder 
buildsystem. This to simplify creation of a deken package of the libary.

See the original README.txt for more information.

For bugs found in this version, please report them to me. Olaf is not 
responsible for bugs introduced by me.

Fred Jan Kraan fjkraan@xs4all.nl 2016-05-07
